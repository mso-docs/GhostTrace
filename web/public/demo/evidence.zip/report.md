# GhostTrace evidence report

Experiment: c5a17744-e78b-4254-bb6f-ba3728286171
Manifest SHA-256: 97db47524c8845c5c1bffba519e24abd662850dd9d1d26433dbe3feb76b44a84
Analysis: d58771a7-b1a8-4f9b-9b41-38a9c48da98e
Status: measured
Split: development
Development diagnostic — exploratory

## Interpretation
Persona conditions change instructions. These measurements do not establish remorse, consciousness, guilt, or a moral center. Distances are descriptive, not causal evidence.

## Primary endpoint
Zero-based block 11; normalized L2; first 16 verified continuation tokens. Scenario-level paired means, 2,000 bootstrap draws.

| Contrast | Mean | 95% interval | Scenarios |
|---|---:|---|---:|
| factual-wording | Unavailable | Unavailable–Unavailable | 0 |
| label-only-neutral | 0.043086 | 0.042783–0.043613 | 3 |
| neutral-repeat | 0.000000 | 0.000000–0.000000 | 3 |
| neutral-wording | 0.047279 | 0.045704–0.049152 | 3 |
| remorseful-neutral | 0.047545 | 0.047097–0.048052 | 3 |
| remorseful-unremorseful | 0.038456 | 0.036891–0.040096 | 3 |
| unremorseful-neutral | 0.037294 | 0.036370–0.038297 | 3 |

## Secondary representation metrics
Cosine distance is unavailable when either vector norm is near zero. Norm ratio a/b measures magnitude and is not a distance.

| Contrast | Cosine distance at primary block | Norm ratio at primary block |
|---|---:|---:|
| factual-wording | Unavailable | Unavailable |
| label-only-neutral | 0.0009129850846399205 | 0.9945631669136189 |
| neutral-repeat | 0.0 | 0.999999998953112 |
| neutral-wording | 0.0011181385478277555 | 0.9993129069189299 |
| remorseful-neutral | 0.0011342060100960432 | 0.9937779409023295 |
| remorseful-unremorseful | 0.0007310334573278529 | 0.9949703229636641 |
| unremorseful-neutral | 0.0007708589058360582 | 0.9988015017447234 |

## Descriptive output behavior
Expressed behavior and weak lexical phrase-count proxies; not emotional-state or remorse scores. Template units are averaged within scenario before scenario bootstrap.

| Condition | Completed / planned outputs | Mean generated tokens | Mean words | Truncation fraction | Continuation NLL |
|---|---:|---:|---:|---:|---:|
| neutral | 6 / 6 | 20.1667 | 14.3333 | 0.0000 | 3.8594 |
| remorseful | 6 / 6 | 29.3333 | 23.0000 | 0.0000 | 3.9311 |
| unremorseful | 6 / 6 | 33.5000 | 27.1667 | 0.0000 | 3.7462 |

Absent refusal/malformed flags remain unavailable; they are never inferred as false.

## Blinded expressed-behavior ratings
Raters: 0; unique ratings: 0.
- Small-sample agreement and kappa estimates are descriptive; wording can reveal prompt condition despite metadata blinding.
- Agreement pairs the same run unit and rubric version. Original scores and disagreements are retained; there is no automatic adjudication.
- Fewer than two raters: inter-rater reliability is unavailable and kappa is omitted.

## Missingness
Excluded records/pairs: 0

## Limitations
- Persona instructions describe experimental conditions, not feelings.
- Activation distance is descriptive, not causal evidence.
- Absolute token positions may differ across prompts.
- Human ratings and family sensitivity are required to contextualize this pilot.
